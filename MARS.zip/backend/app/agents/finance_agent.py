from typing import Any, Dict

from app.agents.common import (
    build_case_evidence,
    build_json_prompt,
    empty_agent_result,
    extract_messages_and_query,
    parse_structured_output,
    retrieve_case_context,
    run_llm_with_tools,
    get_llm,
)
from app.state import State
from app.tools.tool_registry import get_tool_objects_for_agent


def finance_agent(state: State) -> Dict[str, Any]:
    """
    Finance Agent:
    - Retrieves similar financial cases from Supabase (pgvector)
    - Performs financial reasoning using an LLM
    - Outputs a structured recommendation
    """
    messages, query = extract_messages_and_query(state)
    if not messages:
        return empty_agent_result("finance_output", messages)

    cases, case_text, warnings = retrieve_case_context(query=query, domain="finance")
    tools = get_tool_objects_for_agent("finance_agent")

    prompt = build_json_prompt(
        agent_title="Finance Department",
        role_points=[
            "Analyze financial aspects of the problem based strictly on retrieved historical evidence",
            "Use past similar cases from the dataset to guide financial decisions",
            "Refuse to fabricate or speculate if no historical cases exist",
        ],
        rules=[
            "Ground all financial analysis strictly in the retrieved historical cases",
            "Do NOT fabricate financial figures, budgets, VAT models, or ROI estimates without dataset evidence",
            "If no relevant cases were retrieved, return 'No historical evidences/decisions found.' and set confidence to 0.0",
            "Confidence must reflect the empirical grounding from the retrieved cases [0.0 to 1.0]",
        ],
        query=query,
        case_text=case_text,
        tool_names=[t.name for t in tools],
    )

    content, tools_used, final_message = run_llm_with_tools(
        get_llm(state.get("model")), prompt, tools, agent_name="finance_agent"
    )
    parsed_output = parse_finance_output(content)
    parsed_output.update(build_case_evidence(cases, tools_used, reported_confidence=parsed_output.get("confidence")))
    if warnings:
        parsed_output["warnings"] = warnings

    return {
        "finance_output": parsed_output,
        "messages": messages + [final_message],
    }


def parse_finance_output(text: str) -> Dict[str, Any]:
    """Parse structured fields from Finance LLM output."""
    return parse_structured_output(text)
